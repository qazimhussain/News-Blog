console.log("Qazmoviesflix");

let section_1=document.getElementById("section-1")
let section_2=document.getElementById("section-2")
let header=document.getElementsByClassName("header");

window.addEventListener("scroll",elem=>{


if(window.scrollY>0)
{
    Array.from(header).forEach(elem=>{
        elem.classList.add("bg-black","border-dark","border-bottom","position-fixed" )
        elem.classList.remove("bg-black-80")
    

    })
}
else{
    Array.from(header).forEach(elem=>{

        elem.classList.remove("bg-black","border-dark","border-bottom","position-fixed")
        elem.classList.add("bg-black-80")

    })

}
})


console.log(window.location)



if(document.body.classList.contains("home-page"))

{
// trend

let trendrightbtn=document.getElementById("trendrightbtn")
let trendleftbtn=document.getElementById("trendleftbtn")
let trendingrow=document.getElementById("trendingrow")

// popular

let popmoviesrightbtn=document.getElementById("popmoviesrightbtn")
let popmoviesleftbtn=document.getElementById("popmoviesleftbtn");
let popularmoviesrow=document.getElementById("popularmoviesrow")

// indian

let indmoviesrightbtn=document.getElementById("indmoviesrightbtn")
let indmoviesleftbtn=document.getElementById("indmoviesleftbtn");
let indianmoviesrow=document.getElementById("indianmoviesrow");


//popular tvshows

let tvshowsrow=document.getElementById("tvshowsrow")
let tvshowsrightbtn=document.getElementById("tvshowsrightbtn")
let tvshowsleftbtn=document.getElementById("tvshowsleftbtn");

// indshows

let indtvshowsrow=document.getElementById("indshowsrow")
let indtvshowsrightbtn=document.getElementById("indshowsrightbtn")
let indtvshowsleftbtn=document.getElementById("indshowsleftbtn");


// thrillershows

let thrillershowsrow=document.getElementById("thrillershowsrow")
let thrillershowsrightbtn=document.getElementById("thrillershowsrightbtn")
let thrillershowsleftbtn=document.getElementById("thrillershowsleftbtn");

// thrillermovies

let thrillermoviesrow=document.getElementById("thrillermoviesrow")
let thrillermoviesrightbtn=document.getElementById("thrillermoviesrightbtn")
let thrillermoviesleftbtn=document.getElementById("thrillermoviesleftbtn");

// topratedshows

let topratedshowsrow=document.getElementById("topratedshowsrow")
let topratedshowsrightbtn=document.getElementById("topratedshowsrightbtn")
let topratedshowsleftbtn=document.getElementById("topratedshowsleftbtn");


//topratedmovies

let topratedmoviesrow=document.getElementById("topratedmoviesrow")
let topratedmoviesrightbtn=document.getElementById("topratedmoviesrightbtn")
let topratedmoviesleftbtn=document.getElementById("topratedmoviesleftbtn");

// actionshows

let actionshowsrow=document.getElementById("actionshowsrow")
let actionshowsrightbtn=document.getElementById("actionshowsrightbtn")
let actionshowsleftbtn=document.getElementById("actionshowsleftbtn");


//actionmovies

let actionmoviesrow=document.getElementById("actionmoviesrow")
let actionmoviesrightbtn=document.getElementById("actionmoviesrightbtn")
let actionmoviesleftbtn=document.getElementById("actionmoviesleftbtn");

// comedyshows

let comedyshowsrow=document.getElementById("comedyshowsrow")
let comedyshowsrightbtn=document.getElementById("comedyshowsrightbtn")
let comedyshowsleftbtn=document.getElementById("comedyshowsleftbtn");


//comedymovies

let comedymoviesrow=document.getElementById("comedymoviesrow")
let comedymoviesrightbtn=document.getElementById("comedymoviesrightbtn")
let comedymoviesleftbtn=document.getElementById("comedymoviesleftbtn");

// sci_fi_shows

let sci_fi_showsrow=document.getElementById("sci_fi_showsrow")
let sci_fi_showsrightbtn=document.getElementById("sci_fi_showsrightbtn")
let sci_fi_showsleftbtn=document.getElementById("sci_fi_showsleftbtn");


//sci_fi_movies

let sci_fi_moviesrow=document.getElementById("sci_fi_moviesrow")
let sci_fi_moviesrightbtn=document.getElementById("sci_fi_moviesrightbtn")
let sci_fi_moviesleftbtn=document.getElementById("sci_fi_moviesleftbtn");

// console.log(sci_fi_moviesrow.scrollWidth);


// sci_fi_moviesrow.addEventListener("scroll",elem=>)

sci_fi_moviesrow.addEventListener("scroll",elem=>{

})

console.log(sci_fi_moviesrow.scrollWidth,sci_fi_moviesrow.clientWidth);


// console.log(sci_fi_moviesrow.scrollWidth,sci_fi_moviesrow.offsetWidth)

function rightbtnscroll(scrollelement,rightbtn)
{

    

    
    scrollelement.addEventListener("scroll",scrollelem=>{

        console.log(scrollelem.target.scrollLeft,scrollelement.scrollLeft+scrollelement.offsetWidth,scrollelement.scrollWidth,scrollelement.offsetWidth);
        if((scrollelement.scrollLeft+scrollelement.offsetWidth)>=(scrollelement.scrollWidth-10))
    {
        rightbtn.setAttribute("disabled","");
        rightbtn.classList.remove("d-md-inline")
    }
    else{
        rightbtn.removeAttribute("disabled","");
        rightbtn.classList.add("d-md-inline")
    }

    })
    rightbtn.addEventListener("click",btn=>{
        // console.log(scrollelement.offsetWidth);

        scrollelement.scrollLeft+=scrollelement.offsetWidth
    })
}

function leftbtnscroll(scrollelement,leftbtn)
{
  

  
    
    scrollelement.addEventListener("scroll",scrollelem=>{
        if(scrollelement.scrollLeft==0)
        {
            leftbtn.setAttribute("disabled","");
            leftbtn.classList.remove("d-md-inline")
        }
        else{
            leftbtn.removeAttribute("disabled","");
            leftbtn.classList.add("d-md-inline")
        }
        // console.log(scrollelem)

    })
    leftbtn.addEventListener("click",btn=>{
        scrollelement.scrollLeft-=scrollelement.offsetWidth;
    })
}

todaydate=new Date();
console.log(todaydate.getDate(),todaydate)




    // trending row

    let xhrtrend=new XMLHttpRequest();

    let trendingurl="https://api.themoviedb.org/3/trending/all/week?api_key=7c0e9fb0f36aedea6e87df7efacb4f61"

    xhrtrend.open("GET",trendingurl,true)

    xhrtrend.onload=function(){
        if(this.status==200)
        {
            let trendingobj=JSON.parse(this.responseText)
            
            trendingobjarr=trendingobj.results
            console.log(trendingobjarr);


            trendingobjarr.forEach(elem => {

                // console.log(elem)

                if(elem.media_type=="movie")

                {

                    trendingrow.innerHTML+=`
                    <div class="col-sm-4 hover-scale col-md-3  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" data-bs-type=${elem.media_type} id=${elem.id}>
                              
                    <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                    <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                    </div>
                                   
                                    <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.original_title}</h6>
    
                                    
    
                                </div>
                    `
                }

                else{
                    trendingrow.innerHTML+=`
                    <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column  px-0 " data-bs-type=${elem.media_type} id=${elem.id}>
                    <div class="ratio ratio-3x4  border border-theme box-shadow rounded-2">
                    <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover" >
                    </div>
                                    <h6 class="trending-title my-3 fs-chng2  text-center">${elem.name}</h6>
    
                                    
    
                                </div>
                    `
                }

                
            });

            
            rightbtnscroll(trendingrow,trendrightbtn)
            leftbtnscroll(trendingrow,trendleftbtn)

        }
        
       
    }
    xhrtrend.send();

   





    // popular movies

   let  xhrpopmovies=new XMLHttpRequest();

    // with_original_language=hi to use particular language movies

  let  popmoviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_average.gte=8.1&vote_count.gte=2800";
    

    xhrpopmovies.open("GET",popmoviesurl,true);

    xhrpopmovies.onload=function(){
         popmoviesobj=(JSON.parse(this.responseText)).results;
         console.log(popmoviesobj);


         popmoviesobj.forEach(elem => {

            // console.log(elem)

           

            

                popularmoviesrow.innerHTML+=`
                <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                =${elem.id} data-bs-type="movie">
                          
                <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                </div>
                               
                                <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>

                                

                            </div>
                `
            

           

            
        });
        rightbtnscroll(popularmoviesrow,popmoviesrightbtn)
    leftbtnscroll(popularmoviesrow,popmoviesleftbtn)
    }

    xhrpopmovies.send();

    




    // indian movies

     
  let xhrindmovies=new XMLHttpRequest();

    // with_original_language=hi to use particular language movies

  let  indmoviesurl="https://api.themoviedb.org/3/movie/popular?with_original_language=hi&api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_count.gte=30&vote_average.gte=7.5";
    

  xhrindmovies.open("GET",indmoviesurl,true)

  xhrindmovies.onload=function(){
         indmoviesobj=(JSON.parse(this.responseText)).results;
         console.log(indmoviesobj);


         indmoviesobj.forEach(elem => {

            // console.log(elem)

           

            

                indianmoviesrow.innerHTML+=`
                <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                =${elem.id} data-bs-type="movie">
                          
                <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                </div>
                               
                                <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>

                                

                            </div>
                `
            

           

            
        });
        
    rightbtnscroll(indianmoviesrow,indmoviesrightbtn)
    leftbtnscroll(indianmoviesrow,indmoviesleftbtn)

    }

    xhrindmovies.send();



    // tv shows

     

     
   let  xhrtvshows=new XMLHttpRequest();

     // with_original_language=hi to use particular language movies
 
  let   tvshowsurl="https://api.themoviedb.org/3/discover/tv?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_count.gte=6700";
     
 
     xhrtvshows.open("GET",tvshowsurl,true);

     xhrpopmovies.onloadstart=(e)=>{
console.log(e)
     }
 
     xhrtvshows.onload=function(){
        tvshowsobj=(JSON.parse(this.responseText)).results;
          console.log(tvshowsobj);
 
 
          tvshowsobj.forEach(elem => {
 
            //  console.log(elem)
 
            
 
             
 
                 tvshowsrow.innerHTML+=`
                 <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id
                 =${elem.id} data-bs-type="tv">
                           
                 <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                 <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                 </div>
                                
                                 <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
 
                                 
 
                             </div>
                 `
             
 
            
 
             
         });
         rightbtnscroll(tvshowsrow,tvshowsrightbtn)
         leftbtnscroll(tvshowsrow,tvshowsleftbtn)
     }
 
     xhrtvshows.send();
 
    




    //  indian tv show

    
     
   let  xhrindtvshows=new XMLHttpRequest();

   // with_original_language=hi to use particular language movies

let indtvshowsurl="https://api.themoviedb.org/3/discover/tv?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_count.gte=13&with_original_language=hi&with_genres=80|9648|10765|10759|16";
   

xhrindtvshows.open("GET",indtvshowsurl,true)

xhrindtvshows.onload=function(){
      indtvshowsobj=(JSON.parse(this.responseText)).results;
        console.log(indtvshowsobj);


        indtvshowsobj.forEach(elem => {

          //  console.log(elem)

          

           

               indtvshowsrow.innerHTML+=`
               <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id
               =${elem.id} data-bs-type="tv">
                         
               <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
               <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
               </div>
                              
                               <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>

                               

                           </div>
               `
           

          

           
       });
       
   rightbtnscroll(indtvshowsrow,indtvshowsrightbtn)
   leftbtnscroll(indtvshowsrow,indtvshowsleftbtn)
   }

   xhrindtvshows.send();




    //  thriller shows
    
    let  xhrthrillershows=new XMLHttpRequest();

    // with_original_language=hi to use particular language movies

    // network ids
    // netflix:213
    // &with_networks=2739
    // amazonprime:1024
    // hotstar:2739

 let   thrillershowsurl="https://api.themoviedb.org/3/tv/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_average.gte=7.8&vote_count.gte=2000&with_genres=9648";
    

 xhrthrillershows.open("GET",thrillershowsurl,true)

 xhrthrillershows.onload=function(){
    thrillershowsobj=(JSON.parse(this.responseText)).results;
         console.log(thrillershowsobj);


         thrillershowsobj.forEach(elem => {

            // console.log(elem)

           

            

            thrillershowsrow.innerHTML+=`
                <div class="col-sm-4 col-md-3 hover-scale  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id
                =${elem.id} data-bs-type="tv">
                          
                <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                </div>
                               
                                <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>

                                

                            </div>
                `
            

           

            
        });
        rightbtnscroll(thrillershowsrow,thrillershowsrightbtn)
        leftbtnscroll(thrillershowsrow,thrillershowsleftbtn)
    
    }

    xhrthrillershows.send();

   



    // thrillermovies




    let  xhrthrillermovies=new XMLHttpRequest();

    // with_original_language=hi to use particular language movies

    // network ids
    // netflix:213
    // &with_networks=2739
    // amazonprime:1024
    // hotstar:2739

 let   thrillermoviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_average.gte=7.6&vote_count.gte=6000&with_genres=53|9648";
    

 xhrthrillermovies.open("GET",thrillermoviesurl,true)

 xhrthrillermovies.onload=function(){
    thrillermoviesobj=(JSON.parse(this.responseText)).results;
         console.log(thrillermoviesobj);


         thrillermoviesobj.forEach(elem => {

            // console.log(elem)

           

            

            thrillermoviesrow.innerHTML+=`
                <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                =${elem.id} data-bs-type="movie">
                          
                <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                </div>
                               
                                <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>

                                

                            </div>
                `
            

           

            
        });
        rightbtnscroll(thrillermoviesrow,thrillermoviesrightbtn)
        leftbtnscroll(thrillermoviesrow,thrillermoviesleftbtn)
    }

    xhrthrillermovies.send();

   



    // topratedshows



    


       


     let  xhrtopratedshows=new XMLHttpRequest();

     // with_original_language=hi to use particular language movies
 
     // network ids
     // netflix:213
     // &with_networks=2739
     // amazonprime:1024
     // hotstar:2739
 
  let   topratedshowsurl="https://api.themoviedb.org/3/tv/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_average.gte=8.6&vote_count.gte=1300";
     
 
  xhrtopratedshows.open("GET",topratedshowsurl,true)
 
  xhrtopratedshows.onload=function(){
     topratedshowsobj=(JSON.parse(this.responseText)).results;
          console.log(topratedshowsobj);
 
 
          topratedshowsobj.forEach(elem => {
 
             // console.log(elem)
 
            
 
             
 
             topratedshowsrow.innerHTML+=`
                 <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id
                 =${elem.id} data-bs-type="tv">
                           
                 <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                 <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                 </div>
                                
                                 <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
 
                                 
 
                             </div>
                 `
             
 
            
 
             
         });
         rightbtnscroll(topratedshowsrow,topratedshowsrightbtn)
         leftbtnscroll(topratedshowsrow,topratedshowsleftbtn)
    
     }
 
     xhrtopratedshows.send();
 
    





    //  topratedmovies



    let  xhrtopratedmovies=new XMLHttpRequest();

     // with_original_language=hi to use particular language movies
 
     // network ids
     // netflix:213
     // &with_networks=2739
     // amazonprime:1024
     // hotstar:2739
 
  let   topratedmoviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&vote_average.gte=8.45&with_original_language=en|hi&vote_count.gte=200";
     
 
  xhrtopratedmovies.open("GET",topratedmoviesurl,true)
 
  xhrtopratedmovies.onload=function(){
    topratedmoviesobj=(JSON.parse(this.responseText)).results;
          console.log(topratedmoviesobj);
 
 
          topratedmoviesobj.forEach(elem => {
 
             // console.log(elem)
 
            
 
             
 
             topratedmoviesrow.innerHTML+=`
                 <div class="col-sm-4 col-md-3 hover-scale  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                 =${elem.id} data-bs-type="movie">
                           
                 <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                 <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                 </div>
                                
                                 <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>
 
                                 
 
                             </div>
                 `
             
 
            
 
             
         });
         rightbtnscroll(topratedmoviesrow,topratedmoviesrightbtn)
         leftbtnscroll(topratedmoviesrow,topratedmoviesleftbtn)
     }
 
     xhrtopratedmovies.send();
 
   


 





      // actionshows



    


       


      let  xhractionshows=new XMLHttpRequest();

      // with_original_language=hi to use particular language movies
  
      // network ids
      // netflix:213
      // &with_networks=2739
      // amazonprime:1024
      // hotstar:2739
  
   let   actionshowsurl="https://api.themoviedb.org/3/tv/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=10759,18&vote_average.gte=8&without_genres=16";
      
  
   xhractionshows.open("GET", actionshowsurl,true)
  
   xhractionshows.onload=function(){
      actionshowsobj=(JSON.parse(this.responseText)).results;
           console.log(actionshowsobj);
  
  
           actionshowsobj.forEach(elem => {
  
              // console.log(elem)
  
             
  
              
  
              actionshowsrow.innerHTML+=`
                  <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                  =${elem.id} data-bs-type="tv" >
                            
                  <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                  <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                  </div>
                                 
                                  <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
  
                                  
  
                              </div>
                  `
              
  
             
  
              
          });
          rightbtnscroll(actionshowsrow,actionshowsrightbtn)
          leftbtnscroll(actionshowsrow,actionshowsleftbtn)
      }
  
      xhractionshows.send();
  
     
 
 
 
 
 
      
     //  actionmovies
 
 
 
     let  xhractionmovies=new XMLHttpRequest();
 
      // with_original_language=hi to use particular language movies
  
      // network ids
      // netflix:213
      // &with_networks=2739
      // amazonprime:1024
      // hotstar:2739
  
   let   actionmoviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=28,80&vote_count.gte=4500&vote_average.gte=6.8";
      
  
   xhractionmovies.open("GET",actionmoviesurl,true)
  
   xhractionmovies.onload=function(){
    actionmoviesobj=(JSON.parse(this.responseText)).results;
           console.log(actionmoviesobj);
  
  
           actionmoviesobj.forEach(elem => {
  
              // console.log(elem)
  
             
  
              
  
              actionmoviesrow.innerHTML+=`
                  <div class="col-sm-4 col-md-3 hover-scale  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                  =${elem.id} data-bs-type="movie">
                            
                  <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                  <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                  </div>
                                 
                                  <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>
  
                                  
  
                              </div>
                  `
              
  
             
  
              
          });
          rightbtnscroll(actionmoviesrow,actionmoviesrightbtn)
          leftbtnscroll(actionmoviesrow,actionmoviesleftbtn)
      }
  
      xhractionmovies.send();
  
     
 



 


      // comedyshows



    


       


      let  xhrcomedyshows=new XMLHttpRequest();

      // with_original_language=hi to use particular language movies
  
      // network ids
      // netflix:213
      // &with_networks=2739
      // amazonprime:1024
      // hotstar:2739
  
   let   comedyshowsurl="https://api.themoviedb.org/3/tv/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=35&with_original_language=hi&vote_average.gte=7&vote_count.gte=4";
      
  
   xhrcomedyshows.open("GET", comedyshowsurl,true)
  
   xhrcomedyshows.onload=function(){
    comedyshowsobj=(JSON.parse(this.responseText)).results;
           console.log(comedyshowsobj);
  
  
           comedyshowsobj.forEach(elem => {
  
              // console.log(elem)
  
             
  
              
  
              comedyshowsrow.innerHTML+=`
                  <div class="col-sm-4 col-md-3 hover-scale  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                  =${elem.id} data-bs-type="tv">
                            
                  <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                  <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                  </div>
                                 
                                  <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
  
                                  
  
                              </div>
                  `
              
  
             
  
              
          });
          rightbtnscroll(comedyshowsrow,comedyshowsrightbtn)
          leftbtnscroll(comedyshowsrow,comedyshowsleftbtn)
      }
  
      xhrcomedyshows.send();
  

 
 
 
 
 
      
     //  comedymovies
 
 
 
     let  xhrcomedymovies=new XMLHttpRequest();
 
      // with_original_language=hi to use particular language movies
  
      // network ids
      // netflix:213
      // &with_networks=2739
      // amazonprime:1024
      // hotstar:2739
  
   let   comedymoviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=35,10749&vote_count.gte=1200&primary_release_date.gte=1995-09-09&vote_average.gte=7.2&with_original_language=hi|en";
      
  
   xhrcomedymovies.open("GET",comedymoviesurl,true)
  
   xhrcomedymovies.onload=function(){
    comedymoviesobj=(JSON.parse(this.responseText)).results;
           console.log(comedymoviesobj);
  
  
           comedymoviesobj.forEach(elem => {
  
              // console.log(elem)
  
             
  
              
  
              comedymoviesrow.innerHTML+=`
                  <div class="col-sm-4 col-md-3 hover-scale  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                  =${elem.id} data-bs-type="movie">
                            
                  <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                  <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                  </div>
                                 
                                  <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>
  
                                  
  
                              </div>
                  `
              
  
             
  
              
          });
          rightbtnscroll(comedymoviesrow,comedymoviesrightbtn)
      leftbtnscroll(comedymoviesrow,comedymoviesleftbtn)
      }
  
      xhrcomedymovies.send();
  
      
 

  



     // sci_fi_shows



    


       


     let  xhrsci_fi_shows=new XMLHttpRequest();

     // with_original_language=hi to use particular language movies
 
     // network ids
     // netflix:213
     // &with_networks=2739
     // amazonprime:1024
     // hotstar:2739
 
  let  sci_fi_showsurl="https://api.themoviedb.org/3/tv/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=10765&with_original_language=en|hi&vote_average.gte=8&vote_count.gte=800";
     
 
  xhrsci_fi_shows.open("GET", sci_fi_showsurl,true)
 
  xhrsci_fi_shows.onload=function(){
    sci_fi_showsobj=(JSON.parse(this.responseText)).results;
          console.log(sci_fi_showsobj);
 
 
          sci_fi_showsobj.forEach(elem => {
 
             // console.log(elem)
 
            
 
             
 
             sci_fi_showsrow.innerHTML+=`
                 <div class="col-sm-4 col-md-3  hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                 =${elem.id} data-bs-type="tv">
                           
                 <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                 <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                 </div>
                                
                                 <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
 
                                 
 
                             </div>
                 `
             
 
            
 
             
         });
         rightbtnscroll(sci_fi_showsrow,sci_fi_showsrightbtn)
     leftbtnscroll(sci_fi_showsrow,sci_fi_showsleftbtn)
     }
 
     xhrsci_fi_shows.send();
 
     





     
    //  sci_fi_movies



    let  xhrsci_fi_movies=new XMLHttpRequest();

     // with_original_language=hi to use particular language movies
 
     // network ids
     // netflix:213
     // &with_networks=2739
     // amazonprime:1024
     // hotstar:2739
 
  let   sci_fi_moviesurl="https://api.themoviedb.org/3/movie/popular?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&with_genres=878&vote_count.gte=3000&vote_average.gte=7.1&with_original_language=hi|en&primary_release_date.gte=2006-09-09&without_genres=10751|27";
     
 
  xhrsci_fi_movies.open("GET",sci_fi_moviesurl,true)

  
  
 
  xhrsci_fi_movies.onload=function(){
     
    sci_fi_moviesobj=(JSON.parse(this.responseText)).results;
          console.log(sci_fi_moviesobj);
 
 
          sci_fi_moviesobj.forEach(elem => {
 
             // console.log(elem)
 
            
 
             
 
             sci_fi_moviesrow.innerHTML+=`
                 <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
                 =${elem.id} data-bs-type="movie">
                           
                 <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                 <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                 </div>
                                
                                 <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>
 
                                 
 
                             </div>
                 `
             
 
            
 
             
         });
         rightbtnscroll(sci_fi_moviesrow,sci_fi_moviesrightbtn)
     leftbtnscroll(sci_fi_moviesrow,sci_fi_moviesleftbtn);
     }
 
     xhrsci_fi_movies.send();
 
     

    
    }





     function movieandtvitems(showelem)
     {
        let showelemid=showelem.id


        if(showelem.getAttribute("data-bs-type")=="movie")
        {
        
        window.open(`showitems.html?mda_tp=movie&elid=${showelemid}`,"_self")
        }
        else{
            
        window.open(`showitems.html?mda_tp=tv&elid=${showelemid}`,"_self")

        }
     }


     document.addEventListener("click",e=>{
        //  console.log(e.target.parentElement);

         if(e.target.parentElement.classList.contains("hover-scale"))
         {
             let showelem=e.target.parentElement
             movieandtvitems(showelem)

           
         }
         else if(e.target.parentElement.parentElement.classList.contains("hover-scale"))
         {
            console.log("World")
            let showelem=e.target.parentElement.parentElement
            movieandtvitems(showelem)
           
            



         }
     })




    //  let xhrdemo=new XMLHttpRequest();

    //  xhrdemo.open("GET","https://api.themoviedb.org/3/movie/580489?api_key=7c0e9fb0f36aedea6e87df7efacb4f61")

    //  xhrdemo.onload=function(){
    //      console.log(JSON.parse(this.responseText)  )
    //  }

    //  xhrdemo.send()


    
     
     window.addEventListener("scroll",windowelem=>{
// console.log(window.scrollY)
     })


    //  Array.from(genre_list).forEach(listitem=>{
    //      listitem.addEventListener("click",targetelem=>{
    //         console.log(window.scrollY);



            
             

          

    //         console.log(window.scrollY)
    //      })
    //  })
    let sub_header=document.querySelectorAll(".sub-navbar a")


    sub_header.forEach(elem3=>{
        // elem.setAttribute('data-bs-dismiss',"offcanvas")
        elem3.classList.add("hide-canvas")

    })

   
    console.log("Hello","bjdfbjj")

    let menuoffcanvas=document.querySelectorAll(".menuoffcanvas")

    


    let trending_collapse=document.getElementsByClassName("not-collapse");

    let acc_btn=document.querySelectorAll(".accordion-button")

    let hide_canvas=document.querySelectorAll(".hide-canvas")


  

    hide_canvas.forEach(elem=>{
        // elem.setAttribute('data-bs-dismiss',"offcanvas")

        elem.addEventListener("click",()=>{

            menuoffcanvas.forEach(elem2=>{
                let menuactive=new bootstrap.Offcanvas(elem2)
    
                elem2.classList.remove("show")

                elem2.style.visibility="hidden"

                document.body.lastElementChild.remove()
                document.body.style.overflow="auto"
                
            })

           

          
           

        })

       
    })

    Array.from(trending_collapse).forEach(elem2=>{
        elem2.addEventListener("click",trend=>{
            acc_btn.forEach(elem=>{
                if(!(elem.classList.contains("collapsed")))
                {
                   elem.classList.add("collapsed")
                   elem.parentElement.nextElementSibling.classList.remove("show")
                }
            })
        })
    })

  
acc_btn.forEach((elem,i)=>{
    elem.addEventListener('click',()=>{

        acc_btn.forEach(elem2=>{

            elem2.classList.remove("active","trend-color")
            if(!(elem2==elem))
            {
            elem2.classList.remove("toggleactive")

            }


        })

        


        
        {
            if(i!=0)
            {


               
                    if(!(elem.classList.contains("toggleactive")))
                    {
                    elem.classList.add("active","toggleactive")
                   
                        
                    }
                    else{
                        elem.classList.remove("active","toggleactive")

                    }
                    
              

                

               
            }
            else{
                elem.classList.add("trend-color")
    
            }
        }

        
      

      
        


    })
})

document.addEventListener("readystatechange",(e)=>{
    console.log(document.readyState)
    if(document.body.classList.contains("home-page"))
{


    if(document.readyState=="complete")
    {
        document.body.children[2].classList.add("d-none")
        document.body.children[0].classList.remove("d-none")

    }



}

})




// search content


if(document.body.classList.contains("home-page"))
{
    let search_content=document.querySelector("#search-content")

    let search_input=document.querySelector(".search-box input")
    let search_heading=document.querySelector(".search-heading")
    
    let loading_search=document.querySelector(".loading-search")
    
    let searchbtn=document.querySelector(".searchbtn")
    
    let searchrow=document.querySelector("#searchrow")
    
    search_input.addEventListener("input",()=>{
        if(search_input.value.length==0)
        {
            section_2.classList.remove("d-none")
            search_content.classList.add("d-none")
        }
        else{
            
        }
       
    })
    
    
    searchbtn.addEventListener("click",searchcont)
    search_input.addEventListener("keypress",entercontent)
    
    
    
    
    function entercontent(e)
    {
        if(e.key=="Enter")
        {
        e.preventDefault()
    
        searchcont()
    
        }
    }
    
    function searchcont(){
    
    
       
    
    
    
    
    
        if(search_input.value.length>0)
        {
            searchrow.innerHTML=""
            search_heading.innerHTML=``
    
            loading_search.classList.remove("d-none")
    
    
    
            section_2.classList.add("d-none")
            search_content.classList.remove("d-none")
    
            let searchurl=`https://api.themoviedb.org/3/search/multi?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&language=en-US&include_adult=false&query=${search_input.value}`
    
            fetch(searchurl).then(response=>{
                return response.json()
            }).then(data=>{
            search_heading.innerHTML=`You searched for "${search_input.value}"`
            loading_search.classList.add("d-none")
    
    
                let contentobj=data.results;
    
                console.log(contentobj,data)
    
    
                let searchvalue=new RegExp(`^${search_input.value}`,"i")
    
                let resultcount=0
    
    
    
                contentobj.forEach(elem=>{
    
                    
    
                    // console.log(showtitle)
    
                    if (searchvalue.test(elem.title)||searchvalue.test(elem.name))
    
                    {
                        resultcount++
                        if(elem.media_type=="movie")
                        {
                            
                            searchrow.innerHTML+=`
                            <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6  position-relative  d-flex flex-column " id
                            =${elem.id} data-bs-type="movie">
                                      
                            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                            <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                            </div>
                                           
                                            <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.title}</h6>
            
                                            
            
                                        </div>
                            `
                        }
        
                        else if(elem.media_type=="tv")
                        {
                            searchrow.innerHTML+=`
                            <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6  position-relative  d-flex flex-column " id
                            =${elem.id} data-bs-type="tv">
                                      
                            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
                            <img src="https://image.tmdb.org/t/p/w500${elem.poster_path}" alt="" class="img-fluid object-cover  " >
                            </div>
                                           
                                            <h6 class="trending-title  fs-chng2 my-3 text-center">${elem.name}</h6>
            
                                            
            
                                        </div>
                            `
                        }
                    }
    
                   
                    
    
    
                    
                    
                })
    
                if(!resultcount)
                {
            search_heading.innerHTML=`Result not found for "${search_input.value}"`
    
                }
            }).catch(()=>{
            search_heading.innerHTML=`Result not found for "${search_input.value}"`
    
            })

            let genrelist=document.querySelectorAll(".genre-list a")

            let navbarlink=document.querySelectorAll(".offcanvas-body a")


            genrelist.forEach(elem=>{

                elem.addEventListener("click",()=>{
                    section_2.classList.remove("d-none")
            search_content.classList.add("d-none")
            search_input.value=''
                })
                
            })
            navbarlink.forEach(elem=>{

                elem.addEventListener("click",()=>{
                    section_2.classList.remove("d-none")
            search_content.classList.add("d-none")
            search_input.value=''

                })
                
            })


           
           
    
    
        }
        else{
            section_2.classList.remove("d-none")
            search_content.classList.add("d-none")
    
    
        }
    }
    
}
else{
    let home_btn=document.querySelector(".home-btn")
    home_btn.addEventListener("click",()=>{
        window.history.back()
    })
}





   
