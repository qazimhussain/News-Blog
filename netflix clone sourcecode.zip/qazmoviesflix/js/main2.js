console.log("Hello","bjdfbjj")

let params=new URLSearchParams(window.location.search);

let ssrow=document.getElementsByClassName("ssrow")


let itemshowcase_section1=document.getElementsByClassName("itemshowcase-section1");

let storylinesec=document.getElementsByClassName("storyline");

let castrow=document.getElementsByClassName("castrow");
let productioncompaniesrow=document.getElementsByClassName("productioncompaniesrow");

let watchtrailersrow=document.getElementsByClassName("watchtrailersrow");

let watch_trailer_btn=document.getElementsByClassName("watch_trailer_btn");


let recommendedmoviesrow=document.getElementsByClassName("recommendedmoviesrow");

let modaltvmovie=document.getElementsByClassName("modal-tv-movie");

let closebtn=document.getElementsByClassName("close-modal");


let movietvabout=document.getElementsByClassName("movietv-about")

let castinfomodal=document.getElementById("castinfomodal")


beforeload=new Date().getTime();

console.log(beforeload)

 // loaded dom


 window.addEventListener("DOMContentLoaded",function(){
    console.log("Dom Loaded")
    
    console.log(document.body.children[0])
    
             
    
    })


   
        window.addEventListener("load",function(){
            console.log("Load Data")
        console.log(document.body.children[0])
    

        

       
       
    
            
    
    
    
        
        
    






// function scrollelemwidth(scrollelement){
//     if(scrollelement.scrollWidth>scrollelement.offsetWidth)
//     {

//     }
// }




    
function rightbtnscroll(scrollelement,rightbtn)
{
    console.log(scrollelement.scrollWidth)

    if(scrollelement.scrollWidth>scrollelement.offsetWidth)
    {
        rightbtn.classList.add("d-md-inline")
        
    }
    else{
        rightbtn.classList.remove("d-md-inline")

    }

    
    scrollelement.addEventListener("scroll",scrollelem=>{


        console.log(scrollelem.target.scrollLeft,scrollelement.scrollLeft+scrollelement.offsetWidth,scrollelement.scrollWidth,scrollelement.offsetWidth);
        if((scrollelement.scrollLeft+scrollelement.offsetWidth)>=(scrollelement.scrollWidth-10))
    {
        rightbtn.setAttribute("disabled","");
        rightbtn.classList.remove("d-md-inline")
    }
    else{
        rightbtn.removeAttribute("disabled","");
        rightbtn.classList.add("d-md-inline")
    }

    })
    rightbtn.addEventListener("click",btn=>{
        // console.log(scrollelement.offsetWidth);

        scrollelement.scrollLeft+=scrollelement.offsetWidth
    })
    console.log(scrollelement)

}

function leftbtnscroll(scrollelement,leftbtn)
{
  

  
    
    scrollelement.addEventListener("scroll",scrollelem=>{
        if(scrollelement.scrollLeft==0)
        {
            leftbtn.setAttribute("disabled","");
            leftbtn.classList.remove("d-md-inline")
        }
        else{
            leftbtn.removeAttribute("disabled","");
            leftbtn.classList.add("d-md-inline")
        }
        // console.log(scrollelem)

    })
    leftbtn.addEventListener("click",btn=>{
        scrollelement.scrollLeft-=scrollelement.offsetWidth;
    })
}
// use release dates for certifications


console.log(params.get("mda_tp"),params.get("elid"))

let movietvid=params.get("elid")
let media_type=params.get("mda_tp");

let movietvurl=`https://api.themoviedb.org/3/${media_type}/${movietvid}?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;

let moveitvcasturl=`https://api.themoviedb.org/3/${media_type}/${movietvid}/credits?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;

let movietvimagesurl=`https://api.themoviedb.org/3/${media_type}/${movietvid}/images?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;
let movietvtrailerurl=`https://api.themoviedb.org/3/${media_type}/${movietvid}/videos?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;
let movietvrecommendedurl=`https://api.themoviedb.org/3/${media_type}/${movietvid}/recommendations?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;






// for movies

if(media_type=="movie")


{
// originalmovie

fetch(movietvurl).then(response=>{
    // console.log(response)
    return response.json()
}).then(data=>{
    console.log(data);
    // data.results.length=6
    Array.from(itemshowcase_section1).forEach(sect=>{
        document.body.style.setProperty("--itemshow-background",`url(https://image.tmdb.org/t/p/w500/${data.backdrop_path})`)

        let posterimg=sect.children[1].children[0].children[0].children[0].children[0].children[0];
        posterimg.setAttribute("src",`https://image.tmdb.org/t/p/w500/${data.poster_path}`)

        let movietitle=sect.children[1].children[0].children[0].children[1].children[0];
        movietitle.innerHTML=`${data.title}`;

        let movietagline=movietitle.nextElementSibling;
        if(data.tagline=="")
        {
            movietagline.classList.add("d-none")

        }
        else{
            movietagline.innerHTML=`"${data.tagline}"`

        }
        console.log(movietitle,movietagline);

        let movietvage=movietagline.nextElementSibling.children[1];
        movietvage.innerHTML=`PG-13`


        let movieruntime=movietagline.nextElementSibling.children[2];

        let moviehrs=parseInt(`${data.runtime}`/60);

        let moviemin=parseInt(`${data.runtime}`%60);


        if(moviehrs==0&&moviemin==0)
        {
            movieruntime.innerHTML=`${moviemin}min`
        }
        else if(moviemin==0)
        {
            movieruntime.innerHTML=`${moviehrs}hr`

        }
        else if(moviehrs==0)
        {
            movieruntime.innerHTML=`${moviemin}min`
        }

        else{
            movieruntime.innerHTML=`${moviehrs}hr ${moviemin}min`

        }


        console.log(movieruntime,moviehrs,moviemin)

        let movielanguage=sect.children[1].children[0].children[0].children[1].children[3].children[0];


        Array.from(data.spoken_languages).forEach(spokelang=>{

            if(spokelang.iso_639_1==data.original_language)
            {
                movielanguage.innerHTML=`  <span class="fw-600">Language :</span> ${spokelang.english_name}`;

            }
        

        

        })

        

        let imdbrating=movielanguage.nextElementSibling;
        imdbrating.innerHTML=` <span class="fw-600">IMDB : </span> <span class="mx-1">${data.vote_average}</span> <i class="bi bi-star-fill text-warning fs-8"></i>`

        let movierelease_date=imdbrating.nextElementSibling
        movierelease_date.innerHTML=`<span class="fw-600"> Release Date : </span> ${data.release_date}`
        console.log(movierelease_date);

        let moviesgenres=movierelease_date.nextElementSibling.children[1];
        moviesgenres.innerHTML=``
        console.log(moviesgenres)

        Array.from(data.genres).forEach((genre,ind)=>{
            console.log(genre.name,data.genres.length,ind)

            if(ind==((data.genres.length)-1))
            {
                moviesgenres.innerHTML+=`${genre.name}`
            }
            else{
                moviesgenres.innerHTML+=`${genre.name}, `

            }
        })



        console.log(movietvabout)


        Array.from(movietvabout).forEach(aboutmovieelem=>{

            aboutmovieelem.classList.remove("invisible")

        })




    })

        // storyline

        Array.from(storylinesec).forEach(overview=>{
            overview.innerHTML=``


            if(data.overview.length!=0)
            {
                overview.innerHTML=`${data.overview}`

            }

            else{
             overview.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
             overview.parentElement.parentElement.parentElement.parentElement.parentElement.nextElementSibling.classList.remove("pt-5")
            }
        })


        //production companies

Array.from(productioncompaniesrow).forEach(productionelem=>{
    console.log(productionelem);

    productionelem.innerHTML=``

    productioncompanyparent=productionelem.parentElement.parentElement.parentElement.parentElement.parentElement
    console.log(productioncompanyparent)

    Array.from(data.production_companies).forEach(prodcomp=>{
        console.log(prodcomp)

        if(prodcomp.logo_path!=null)
        {
            productionelem.innerHTML+=`
            <div class="col-sm-4 hover-elem col-md-3  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id=${prodcomp.id}>
                                  
            <div class="ratio ratio-3x4 border border-theme box-shadow bg-white rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${prodcomp.logo_path}" alt="" class="img-fluid object-contain  " >
            </div>
                           
                            <h6 class="trending-title  fs-chng2 my-3 text-center">${prodcomp.name}</h6>
    
                            
    
                        </div>
            `
        }
        else if(productionelem.innerHTML==``)
        {
            productioncompanyparent.classList.add("d-none")
        }
      
    })


    if(productionelem.innerHTML==``)
       {
        productionelem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
       }
    






    let prodcomprowleftbtn=productionelem.previousElementSibling;
    let prodcomprowrightbtn=prodcomprowleftbtn.previousElementSibling;


     
    rightbtnscroll(productionelem,prodcomprowrightbtn)
    leftbtnscroll(productionelem,prodcomprowleftbtn)




})

 


})


// cast

fetch(moveitvcasturl).then(response=>{
    console.log(response)
    return response.json()
}).then(data=>{

    if(data.cast.length>10)
    {
        data.cast.length=10

    }

    let crewdir=[];
    let crewprod=[]

   console.log(data.crew,data);


//    get writer and director

   Array.from(data.crew).forEach(crewelem=>{
       if(crewelem.job=="Producer"){
           console.log(crewelem);
           crewprod.push(crewelem)
       }
       else if(crewelem.job=="Director")
       {
        console.log(crewelem)
        crewdir.push(crewelem)
        
       }
   })


//    print director

let director=document.getElementsByClassName("director")
let producer=document.getElementsByClassName("producer")



Array.from(director).forEach(directordiv=>{
directordiv.innerHTML=``


    Array.from(crewdir).forEach((direlem,dirind)=>{

        if((dirind+1)==(crewdir.length))
        {
            directordiv.innerHTML+=`${direlem.name}`
        }
        else{
            directordiv.innerHTML+=`${direlem.name}, `

        }

    })
})

//    print producer


Array.from(producer).forEach(producerdiv=>{
    producerdiv.innerHTML=``
    
    
        Array.from(crewprod).forEach((prodelem,prodind)=>{
    
            if((prodind+1)==(crewprod.length))
            {
                producerdiv.innerHTML+=`${prodelem.name}`
            }
            else{
                producerdiv.innerHTML+=`${prodelem.name}, `
    
            }
    
        })
    })

   


   console.log(crewdir,crewprod,castrow)

    Array.from(castrow).forEach(rowelem=>{
        rowelem.innerHTML=``
        Array.from(data.cast).forEach(castelem=>{
            console.log(castelem.profile_path,castelem);
            if(castelem.profile_path!=null)
            {

            rowelem.innerHTML+=`
            <div class="col-sm-4 hover-elem leadrole col-md-3  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0 z-99"  id=${castelem.id}>
                              
            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${castelem.profile_path}" alt="" class="img-fluid object-cover  " >
            </div>

            <div class="flex flex-column mt-2">
            <h6 class="trending-title  fs-chng2 my-2  text-center">${castelem.name}</h6>
           
            <h6 class="trending-title  z-99 fs-8 text-muted m-0 text-center">${castelem.character}</h6>


            
            </div>
                           

                            

                        </div>
            `
        }

        // console.log(rowelem.innerHTML==)


       

    })

    if(rowelem.innerHTML==``)
       {
        console.log(rowelem.parentElement.parentElement.parentElement.parentElement)
        rowelem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
       }

    console.log(data.cast)

    let castrowleftbtn=rowelem.previousElementSibling;
    let castrowrightbtn=castrowleftbtn.previousElementSibling;


     
    rightbtnscroll(rowelem,castrowrightbtn)
    leftbtnscroll(rowelem,castrowleftbtn)




        let leadrole=this.document.getElementsByClassName("leadrole")


        Array.from(leadrole).forEach(leadelem=>{
            leadelem.addEventListener("click",()=>{
                console.log(leadelem.id)
    
    
                let leadmodalactive=new bootstrap.Modal(castinfomodal)

            castinfomodal.children[0].children[0].classList.add("loading")


                leadmodalactive.show()


                

    
    
                let moviepeople=`https://api.themoviedb.org/3/person/${leadelem.id}?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&append_to_response=images&sort_by=popularity.desc`
    
                let moviepeopleshows=`
                https://api.themoviedb.org/3/person/${leadelem.id}/movie_credits?vote_average.gte=8&api_key=7c0e9fb0f36aedea6e87df7efacb4f61&language=en-US`
    
    
                fetch(moviepeople).then(response=>{
                    return response.json()
                }).then(actordata=>{
                    console.log(actordata)
    
    
                    // PRofile img
    
    
    
                    let actorimg=castinfomodal.children[0].children[0].children[0].children[0].children[0].children[0].children[0]
    
                    actorimg.setAttribute("src",`https://image.tmdb.org/t/p/w500${actordata.profile_path}`)
    
    
                    // Actor name
    
    
                    let actorname=castinfomodal.children[0].children[0].children[0].children[1].children[0].children[1]
    
                    if(actordata.name!=null)
                    {
                        actorname.innerText=`${actordata.name}`
                        console.log(actorname.innerHTML)
                        actorname.parentElement.classList.remove('d-none')
    
                    }
    
                    else{
                        actorname.parentElement.classList.add('d-none')
                    }
    
                    // Actorbday
    
                   
    
                    let actorbday=castinfomodal.children[0].children[0].children[0].children[1].children[1].children[1]
    
                    if(actordata.birthday!=null)
                    {
                        actorbday.innerText=`${actordata.birthday}`
    
                        console.log(actorname.innerHTML)
                        actorbday.parentElement.classList.remove('d-none')
    
                    }
    
                    else{
                        actorbday.parentElement.classList.add('d-none')
                    }
    
    
    
                    // Actor profession
    
    
                    let actorprofess=castinfomodal.children[0].children[0].children[0].children[1].children[2].children[2]
    
                    if(actordata.known_for_department!=null)
                    {
                        actorprofess.innerText=`${actordata.known_for_department}`
    
    
                        console.log(actorname.innerHTML)
                        actorprofess.parentElement.classList.remove('d-none')
    
                    }
    
                    else{
                        actorprofess.parentElement.classList.add('d-none')
                    }
    
    
                    // Actor overview
    
    
                    let actoroverview=castinfomodal.children[0].children[0].children[0].children[1].children[3].children[2]
    
                    if(actordata.biography!="")
                    {
                        actoroverview.innerText=`${actordata.biography}`
    
    
    
                        console.log(actorname.innerHTML)
                        actoroverview.parentElement.classList.remove('d-none')
    
                    }
    
                    else{
                        actoroverview.parentElement.classList.add('d-none')
                    }
                    
    
                    // Actor images
    
    
    
    
                    let actorimages=castinfomodal.children[0].children[0].children[0].children[1].children[5].children[1]
    
                    Array.from(actordata.images.profiles).forEach(imageselem=>{
    
                        actorimages.innerHTML+=`
                        <div class="col-md-4 col-6 my-2">
                        <div class="ratio ratio-3x4">
                        <img src="https://image.tmdb.org/t/p/w500${imageselem.file_path}" alt="" class="img-fluid object-cover rounded-2 castinfo-images">      
    
                        </div>
                    </div>  
                        `
                        // console.log(imageselem)
                    })
    
                    castinfomodal.addEventListener("hidden.bs.modal",()=>{
                        actorimages.innerHTML=` `
                        actoroverview.innerHTML=""
                        actorprofess.innerHTML=""
                        actorbday.innerHTML=""
                        actorname.innerHTML=""
                    })

                    
    
    
    
    
                    
    
    
    
                   
                fetch(moviepeopleshows).then(response=>{
                    return response.json()
                }).then(popshowsdata=>{
                    console.log(popshowsdata.cast)

                    let popshowsarr= []

                    popshowsdataarr=popshowsdata.cast
    

                    popshowsdataarr.sort((a, b) => b.vote_average - a.vote_average);


                    

                   
                    


                    
   
  


                    
    
                    Array.from(popshowsdataarr).forEach((shows,i)=>{
                        console.log(shows)
                        if(!( shows.character==null ||    shows.character=="Self" || shows.character=="Himself" || shows.character.includes("Self") ||  shows.character.includes("self") || shows.character.includes("voice") || shows.character=="" ||  shows.popularity<5))
                        {
                            console.log(shows,shows.character)


                            if(shows.vote_average>5)

                            {
                                popshowsarr.push(shows.title)

                            }
    
    
                    
    
                        }


    
                       
                    })
    
    
                    if(popshowsarr.length==0)
                    {
                        let popshowsparent=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1].parentElement

                        console.log(popshowsparent)
    
                        popshowsparent.classList.add("d-none")
    
                    }
    
                    else{
    
                        let popshowsparent=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1].parentElement
    
                        popshowsparent.classList.remove("d-none")
    
    
                        popshowsarr=new Set(popshowsarr)

                       console.log(popshowsarr.size)

                       


    
                       Array.from(popshowsarr).forEach((popshowsname,i)=>{
    
    
                            let popshows=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1]


                            popshows.previousElementSibling.innerHTML="Popular Movies :"
    
                            console.log(i,(popshowsarr.size)-1)
    
                           
                           
                                popshows.innerHTML+=` <div class="d-flex mb-1"> <span>${i+1}.</span>     <span class="px-md-2 px-1"> ${popshowsname}. </span> </div> `
    
                    console.log(popshows)
    
                    castinfomodal.addEventListener("hidden.bs.modal",()=>{
                        popshows.innerHTML=``
                    })
                        })
    
    
                    }

            castinfomodal.children[0].children[0].classList.remove("loading")

    
    
                })
    
    
    
    
                })
                
    
    
                // fetch tv show of actor
             
                
            })
            
        })


    })



})


// screenshot

fetch(movietvimagesurl).then(response=>{
    return response.json()
}).then(data=>{
    console.log(data);

    Array.from(ssrow).forEach(sselem=>{

        sselem.innerHTML=``

        Array.from(data.backdrops).forEach(ssimg=>{
            sselem.innerHTML+=`
            <div class="col-sm-6 hover-elem modalimg col-md-4 z-99 mb-20  col-xl-3 col-8 mx-2 position-relative  d-flex flex-column px-0" >
                                  
            <div class="ratio ratio-16x9 border border-theme box-shadow  rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${ssimg.file_path}" alt="" class="img-fluid object-cover " >
            </div>
                           
    
                            
    
                        </div>
            `
        })

        if(sselem.innerHTML==``)
        {
            sselem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
        }

        let ssrowleftbtn=sselem.previousElementSibling;
        let ssrowrightbtn=ssrowleftbtn.previousElementSibling;

        rightbtnscroll(sselem,ssrowrightbtn)
        leftbtnscroll(sselem,ssrowleftbtn)
        
    })

    let imgelem=document.getElementsByClassName("modalimg");
    Array.from(imgelem).forEach(e=>{
        e.addEventListener("click",function(){
            Array.from(modaltvmovie).forEach(modalelem=>{
                let modalelemactive=new bootstrap.Modal(modalelem);

               let modalelembody=modalelem.children[0].children[0].children[0];


                modalelembody.classList.add('loading')

           modalelemactive.show();

                console.log(modalelem.children[0].children[0].children[0]);

                let imgkey=e.children[0].children[0].getAttribute("src")
                // console.log(imgkey)

               modalelembody.innerHTML=`
               <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
               <img src="${imgkey}" alt="" class="img-fluid object-cover modal-border-radius" style="opacity:0.9;">
           </div>
                  
           `
           modalelembody.classList.remove('loading')



            })
        })
    })
})


// watch trailers


fetch(movietvtrailerurl).then(response=>{
    return response.json()
}).then(data=>{
    console.log(data.results);
    let trailername;
    let trailervidarr=[]
    Array.from(watchtrailersrow).forEach(trailerelemrow=>{

        Array.from(data.results).forEach(trailervid=>{
            trailername=String(trailervid.name);
          let  trailernamelowercase=trailername.toLowerCase()

      
console.log( trailername,trailernamelowercase.includes("trailer"));

if(trailernamelowercase.includes("trailer") && trailernamelowercase.includes("official"))
{
    trailervidarr.push(trailervid)
    trailerelemrow.innerHTML+=
    `
    <div class="col-sm-6 hover-elem modalvideo col-md-4 mb-20 col-xl-3 z-99 col-8 mx-2 position-relative  d-flex flex-column px-0" >
                          
    <div class="ratio ratio-16x9 border border-theme box-shadow  rounded-2">
    <img src="https://i.ytimg.com/vi/${trailervid.key}/hqdefault.jpg" alt="" class="img-fluid object-cover" key=${trailervid.key} >
   
    </div>

    <div class="video-playbtn position-absolute top-50 start-50 translate-middle">
    <img src="photo/25647-2-play-button-transparent-image_800x800.png" alt=""  width="39px" height="39px">
    
</div>

   
    </div>
                   

                    

                </div>
    `

   
}


           
        })

        

        console.log(trailervidarr,trailerelemrow.parentElement.parentElement.parentElement.parentElement.parentElement);
         let trailerrowparent=trailerelemrow.parentElement.parentElement.parentElement.parentElement.parentElement;
        Array.from(watch_trailer_btn).forEach(btnelem=>{
            console.log(btnelem);
            if(trailervidarr.length!=0)
            {
                btnelem.setAttribute("key",trailervidarr[0].key);
                btnelem.style.cursor="pointer";

                let videoelem=document.getElementsByClassName("modalvideo");

                btnelem.addEventListener("click",function(){
                    Array.from(modaltvmovie).forEach(modalelem=>{
                        let modalelemactive=new bootstrap.Modal(modalelem);
                   modalelemactive.show();
            
                        console.log(modalelem.children[0].children[0].children[0]);
            
                        let imgkey=btnelem.getAttribute("key")
                        console.log(imgkey)
                       let modalelembody=modalelem.children[0].children[0].children[0];
            
                       modalelembody.innerHTML=`
                       <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
                       <iframe  src="https://www.youtube.com/embed/${imgkey}" title="YouTube video player" frameborder="0" allow="accelerometer;  clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-100 object-cover"></iframe>
        
                      
            
                   </div>
                          
                   `
                   Array.from(closebtn).forEach(closeelem=>{
                       closeelem.addEventListener("click",function(){
                           modalelembody.innerHTML=``
                       })
                   })
            
            
            
                    })
                })

                
               
                   
                        
                   
               


    
            }
            else{
              btnelem.classList.add("d-none")
              trailerrowparent.classList.add("d-none")
              
            }
        })

       


        let trailerrowleftbtn=trailerelemrow.previousElementSibling;
        let trailerrowrightbtn=trailerrowleftbtn.previousElementSibling;

        rightbtnscroll(trailerelemrow,trailerrowrightbtn)
        leftbtnscroll(trailerelemrow,trailerrowleftbtn)

    })

    let videoelem=document.getElementsByClassName("modalvideo");
    Array.from(videoelem).forEach(e=>{
        e.addEventListener("click",function(){
            Array.from(modaltvmovie).forEach(modalelem=>{
                let modalelemactive=new bootstrap.Modal(modalelem);


                modalelem.children[0].children[0].children[0].classList.add('loading')

           modalelemactive.show();
    
                console.log(modalelem.children[0].children[0].children[0]);
    
                let imgkey=e.children[0].children[0].getAttribute("key")
                console.log(imgkey)
               let modalelembody=modalelem.children[0].children[0].children[0];
    
               modalelembody.innerHTML=`
               <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
               <iframe  src="https://www.youtube.com/embed/${imgkey}" title="YouTube video player" frameborder="0" allow="accelerometer;  clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-100 object-cover"></iframe>

              
    
           </div>
                  
           `

           modalelem.children[0].children[0].children[0].classList.remove('loading')


           Array.from(closebtn).forEach(closeelem=>{
               closeelem.addEventListener("click",function(){
                   modalelembody.innerHTML=``
               })
           })
    
    
    
            })
        })
    })

})








// recommendedmovies

fetch(movietvrecommendedurl).then(response=>{
    console.log()
    return response.json()
}).then(data=>{
    console.log(data.results)

    Array.from(recommendedmoviesrow).forEach(recommendrow=>{

        recommendrow.innerHTML=``

        Array.from(data.results).forEach(recommendmovie=>{
            recommendrow.innerHTML+=`
            <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
            =${recommendmovie.id} data-bs-type="movie">
                      
            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${recommendmovie.poster_path}" alt="" class="img-fluid object-cover  " >
            </div>
                           
                            <h6 class="trending-title  fs-chng2 my-3 text-center">${recommendmovie.title}</h6>

                            

                        </div>`

                        let recommendedrowleftbtn=recommendrow.previousElementSibling;
                        let recommendedrowrightbtn=recommendedrowleftbtn.previousElementSibling;
                
                        rightbtnscroll(recommendrow,recommendedrowrightbtn)
                        leftbtnscroll(recommendrow,recommendedrowleftbtn)

        })

        if(recommendrow.innerHTML==``)
        {
            recommendrow.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
        }

        recommendedparent=recommendrow.parentElement.parentElement.parentElement.previousElementSibling.children[0];
        recommendedparent.innerHTML=`Recommended Movies`

        
    })
})

}

// for tv

else{
    



// originaltv

fetch(movietvurl).then(response=>{
    // console.log(response)
    return response.json()
}).then(data=>{
    console.log(data);
    // data.results.length=6
    Array.from(itemshowcase_section1).forEach(sect=>{
        document.body.style.setProperty("--itemshow-background",`url(https://image.tmdb.org/t/p/w500/${data.backdrop_path})`)

        let posterimg=sect.children[1].children[0].children[0].children[0].children[0].children[0];
        posterimg.setAttribute("src",`https://image.tmdb.org/t/p/w500/${data.poster_path}`);


        let setfirstdate=new Date(`${data.first_air_date}`);
        let setlastdate=new Date(`${data.last_air_date}`);

        let firsttvdate=setfirstdate.getFullYear()
        let lasttvdate=setlastdate.getFullYear()


// setdate.setDate();

        let movietitle=sect.children[1].children[0].children[0].children[1].children[0];

        if(firsttvdate!=lasttvdate)
        {
            movietitle.innerHTML=`${data.name}  <span class="tvmovdate fs-7 fw-light mx-2">(${firsttvdate}-${lasttvdate})</span>`;
        }

        else{
            movietitle.innerHTML=`${data.name}  <span class="tvmovdate fs-7 fw-light mx-2">(${firsttvdate})</span>`;
        }
        

        let movietagline=movietitle.nextElementSibling;
        if(data.tagline=="")
        {
            movietagline.classList.add("d-none")

        }
        else{
            movietagline.innerHTML=`"${data.tagline}"`

        }
        console.log(movietitle,movietagline);

        let movietvage=movietagline.nextElementSibling.children[1];
        movietvage.innerHTML=`TV-14`


        let movieruntime=movietagline.nextElementSibling.children[2];

        movieruntime.innerHTML=`${data.episode_run_time[0]*data.number_of_episodes}min`


        console.log(movieruntime)

        let movielanguage=sect.children[1].children[0].children[0].children[1].children[3].children[0];


        Array.from(data.spoken_languages).forEach(spokelang=>{

            if(spokelang.iso_639_1==data.original_language)
            {
                movielanguage.innerHTML=`  <span class="fw-600">Language :</span> ${spokelang.english_name}`;

            }
        

        

        })

        

        let imdbrating=movielanguage.nextElementSibling;
        imdbrating.innerHTML=` <span class="fw-600">IMDB : </span> <span class="mx-1">${data.vote_average}</span> <i class="bi bi-star-fill text-warning fs-8"></i>`

        let movierelease_date=imdbrating.nextElementSibling
        movierelease_date.innerHTML=` <span class="fw-600">Release Date :</span>     ${data.first_air_date}`
        console.log(movierelease_date);

        let moviesgenres=movierelease_date.nextElementSibling.children[1];
        moviesgenres.innerHTML=``
        console.log(moviesgenres)

        Array.from(data.genres).forEach((genre,ind)=>{
            console.log(genre.name,data.genres.length,ind)

            if(ind==((data.genres.length)-1))
            {
                moviesgenres.innerHTML+=`${genre.name}`
            }
            else{
                moviesgenres.innerHTML+=`${genre.name}, `

            }
        })


        Array.from(movietvabout).forEach(aboutmovieelem=>{

            aboutmovieelem.classList.remove("invisible")

        })





    })

        // storyline

        Array.from(storylinesec).forEach(overview=>{

            overview.innerHTML=``


            if(data.overview.length!=0)
            {
                overview.innerHTML=`${data.overview}`

            }

            else{
             overview.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
             overview.parentElement.parentElement.parentElement.parentElement.parentElement.nextElementSibling.classList.remove("pt-5")
            }
        })

        // director

    let crewdir=data.created_by;

let director=document.getElementsByClassName("director")

Array.from(director).forEach(directordiv=>{
    directordiv.innerHTML=``
    
    
        Array.from(crewdir).forEach((direlem,dirind)=>{
    
            if((dirind+1)==(crewdir.length))
            {
                directordiv.innerHTML+=`${direlem.name}`
            }
            else{
                directordiv.innerHTML+=`${direlem.name}, `
    
            }
    
        })
    })




// watch trailers


console.log()


    movietvtrailerurl=`https://api.themoviedb.org/3/${media_type}/${movietvid}/videos?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;
    

fetch(movietvtrailerurl).then(response=>{
    console.log(response)
    return response.json()
}).then(datavid=>{
    console.log(datavid);
    let trailername;
    let trailervidarr=[];
    let trailervidarr2=[];
    let uniquearr=[];
    let uniquenamearr=[]
    Array.from(watchtrailersrow).forEach(trailerelemrow=>{


        Array.from(data.seasons).forEach((onlyseason,i)=>{
           if(onlyseason.name.includes("Special"))
           {
               console.log(onlyseason);
               data.seasons.splice(i,1);
           }
        })
        console.log(data.seasons)

       

        Array.from(data.seasons).forEach((videostrailer,i)=>{
            if(videostrailer.name.includes("Season"))
            {
                let movietrailerurl2=`https://api.themoviedb.org/3/${media_type}/${movietvid}/season/${i+1}/videos?api_key=7c0e9fb0f36aedea6e87df7efacb4f61`;
                let xhrobj= new XMLHttpRequest();
                xhrobj.open("GET",`${movietrailerurl2}`,false);
                xhrobj.onload=function(){
                    videosdata=JSON.parse(this.responseText);
                    console.log(videosdata)
                    Array.from(videosdata.results).forEach(function(trailerresult){
                        if(trailerresult.name.includes("Trailer"))
                        {
                        console.log(trailerresult)
                         trailervidarr2.push(trailerresult)
                        }
                      })


                }
                xhrobj.send()
                
                        // console.log(videosdata.results)
                       
            }
       
        })

    //    let trailervidarr3=trailervidarr2.join(trailervidarr)

   let trailervidarr3= trailervidarr2.concat(datavid.results)

        // trailervidarrset=new Set(trailervidarr3);

        Array.from(trailervidarr3).forEach((elem,i)=>{
            if(!(uniquenamearr.includes(elem.name)))
            {
                  uniquenamearr.push(elem.name);
                  uniquearr.push(elem)
            }
        })


        Array.from(uniquearr).forEach(trailervid=>{
            trailername=String(trailervid.name);
          let  trailernamelowercase=trailername.toLowerCase()

      
console.log( trailername,trailernamelowercase.includes("trailer"));

if(trailernamelowercase.includes("trailer") && trailernamelowercase.includes("official"))
{
    trailervidarr.push(trailervid)
    trailerelemrow.innerHTML+=
    `
    <div class="col-sm-6 hover-elem modalvideo col-md-4 mb-20 col-xl-3 z-99 col-8 mx-2 position-relative  d-flex flex-column px-0" >
                          
    <div class="ratio ratio-16x9 border border-theme box-shadow  rounded-2">
    <img src="https://i.ytimg.com/vi/${trailervid.key}/hqdefault.jpg" alt="" class="img-fluid object-cover" key=${trailervid.key} >
   
    </div>

    <div class="flex flex-column mt-2">
            <h6 class="trailer-title  fs-chng2 my-2  text-center">${trailervid.name}</h6>
        
            </div>

    <div class="video-playbtn position-absolute top-40 start-50 translate-middle">
    <img src="photo/25647-2-play-button-transparent-image_800x800.png" alt=""  width="39px" height="39px">
    
</div>

   
    </div>
                   

                    

                </div>
    `

   
}


           
        })





        

        console.log(trailervidarr3,uniquearr,uniquenamearr,trailervidarr,trailervidarr2,trailerelemrow.parentElement.parentElement.parentElement.parentElement.parentElement);
         let trailerrowparent=trailerelemrow.parentElement.parentElement.parentElement.parentElement.parentElement;
        Array.from(watch_trailer_btn).forEach(btnelem=>{
            console.log(btnelem);
            if(trailervidarr.length!=0)
            {
                btnelem.setAttribute("key",trailervidarr[0].key);
                btnelem.style.cursor="pointer";

                let videoelem=document.getElementsByClassName("modalvideo");

                btnelem.addEventListener("click",function(){
                    Array.from(modaltvmovie).forEach(modalelem=>{
                        let modalelemactive=new bootstrap.Modal(modalelem);
                   modalelemactive.show();

                   modalelem.children[0].children[0].children[0].classList.add("loading")
            
                        console.log(modalelem.children[0].children[0].children[0]);
            
                        let imgkey=btnelem.getAttribute("key")
                        console.log(imgkey)
                       let modalelembody=modalelem.children[0].children[0].children[0];
            
                       modalelembody.innerHTML=`
                       <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
                       <iframe  src="https://www.youtube.com/embed/${imgkey}" title="YouTube video player" frameborder="0" allow="accelerometer;  clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-100 object-cover"></iframe>
        
                      
            
                   </div>
                          
                   `

                   modalelem.children[0].children[0].children[0].classList.remove("loading")

                   Array.from(closebtn).forEach(closeelem=>{
                       closeelem.addEventListener("click",function(){
                           modalelembody.innerHTML=``
                       })
                   })
            
            
            
                    })
                })

                
               
                   
                        
                   
               


    
            }
            else{
              btnelem.classList.add("d-none")
              trailerrowparent.classList.add("d-none")
              
            }
        })

       


        let trailerrowleftbtn=trailerelemrow.previousElementSibling;
        let trailerrowrightbtn=trailerrowleftbtn.previousElementSibling;

        rightbtnscroll(trailerelemrow,trailerrowrightbtn)
        leftbtnscroll(trailerelemrow,trailerrowleftbtn)

    })

    let videoelem=document.getElementsByClassName("modalvideo");
    Array.from(videoelem).forEach(e=>{
        e.addEventListener("click",function(){
            Array.from(modaltvmovie).forEach(modalelem=>{
                let modalelemactive=new bootstrap.Modal(modalelem);
           modalelemactive.show();
    
                console.log(modalelem.children[0].children[0].children[0]);
    
                let imgkey=e.children[0].children[0].getAttribute("key")
                console.log(imgkey)
               let modalelembody=modalelem.children[0].children[0].children[0];
    
               modalelembody.innerHTML=`
               <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
               <iframe  src="https://www.youtube.com/embed/${imgkey}" title="YouTube video player" frameborder="0" allow="accelerometer;  clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen class="w-100 object-cover"></iframe>

              
    
           </div>
                  
           `

           Array.from(closebtn).forEach(closeelem=>{
               closeelem.addEventListener("click",function(){
                   modalelembody.innerHTML=``
               })
           })
    
    
    
            })
        })
    })

})




    // print seasons and episodes


    let streamplatform=document.getElementsByClassName("streaming")
    
    Array.from(streamplatform).forEach(stream=>{


        if(!(data.networks.length==0))
        {
            stream.innerHTML=`${data.networks[0].name}`
            stream.parentElement.classList.remove("d-none")
        }
        
    })
    
   





        //production companies

Array.from(productioncompaniesrow).forEach(productionelem=>{
    console.log(productionelem);
    productionelem.innerHTML=``
    productioncompanyparent=productionelem.parentElement.parentElement.parentElement.parentElement.parentElement
    console.log(productioncompanyparent)

    Array.from(data.production_companies).forEach(prodcomp=>{
        console.log(prodcomp)

        if(prodcomp.logo_path!=null)
        {
            productionelem.innerHTML+=`
            <div class="col-sm-4 hover-elem col-md-3  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0"  id=${prodcomp.id}>
                                  
            <div class="ratio ratio-3x4 border border-theme box-shadow bg-white rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${prodcomp.logo_path}" alt="" class="img-fluid object-contain  " >
            </div>
                           
                            <h6 class="trending-title  fs-chng2 my-3 text-center">${prodcomp.name}</h6>
    
                            
    
                        </div>
            `
        }
        else if(productionelem.innerHTML==``)
        {
            productioncompanyparent.classList.add("d-none")
        }
        // console.log(productionelem.innerHTML==``,productionelem.innerText)

      
    })

    if(productionelem.innerHTML==``)
    {
     productionelem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
    }






    let prodcomprowleftbtn=productionelem.previousElementSibling;
    let prodcomprowrightbtn=prodcomprowleftbtn.previousElementSibling;


     
    rightbtnscroll(productionelem,prodcomprowrightbtn)
    leftbtnscroll(productionelem,prodcomprowleftbtn)




})

 


})


// cast

fetch(moveitvcasturl).then(response=>{
    console.log(response)
    return response.json()
}).then(data=>{
    console.log(data.cast);

    if (data.cast.length>10)
    {
        data.cast.length=10

    }

    let crewprod=[]

   console.log(data.crew,data);


//    get writer and director

   Array.from(data.crew).forEach(crewelem=>{
       if(crewelem.job=="Producer"){
           console.log(crewelem);
           crewprod.push(crewelem)
       }
       else if(crewelem.job=="Director")
       {
        console.log(crewelem)
        
       }

       
   })


//    print director

let producer=document.getElementsByClassName("producer")











//    print producer



Array.from(producer).forEach(producerdiv=>{
    producerdiv.innerHTML=``

    if (crewprod.length==0){
    producerdiv.innerHTML=``
    producerdiv.parentElement.classList.add("d-none")

    }
    
    
        Array.from(crewprod).forEach((prodelem,prodind)=>{
    
            if((prodind+1)==(crewprod.length))
            {
                producerdiv.innerHTML+=`${prodelem.name}`
            }
            else{
                producerdiv.innerHTML+=`${prodelem.name}, `
    
            }
    
        })
    })

   



    Array.from(castrow).forEach(rowelem=>{
        rowelem.innerHTML=``
        Array.from(data.cast).forEach(castelem=>{
            console.log(castelem,data.cast);
            if((castelem.profile_path)!=null)
            {

            rowelem.innerHTML+=`
            <div class="col-sm-4 hover-elem col-md-3 leadrole  col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0 z-99"  id=${castelem.id}>
                              
            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${castelem.profile_path}" alt="" class="img-fluid object-cover  " >
            </div>

            <div class="flex flex-column mt-2">
            <h6 class="trending-title  fs-chng2 my-2  text-center">${castelem.name}</h6>
           
            <h6 class="trending-title  z-99 fs-8 text-muted m-0 text-center">${castelem.character}</h6>


            
            </div>
                           

                            

                        </div>
            `
        }

    })

    if(rowelem.innerHTML==``)
       {
        console.log(rowelem.parentElement.parentElement.parentElement.parentElement)
        rowelem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
       }

    let castrowleftbtn=rowelem.previousElementSibling;
    let castrowrightbtn=castrowleftbtn.previousElementSibling;


     
    rightbtnscroll(rowelem,castrowrightbtn)
    leftbtnscroll(rowelem,castrowleftbtn)

    let leadrole=this.document.getElementsByClassName("leadrole")


    Array.from(leadrole).forEach(leadelem=>{
        leadelem.addEventListener("click",()=>{
            console.log(leadelem.id)


            let leadmodalactive=new bootstrap.Modal(castinfomodal)

            castinfomodal.children[0].children[0].classList.add("loading")

            leadmodalactive.show()


            let tvpeople=`https://api.themoviedb.org/3/person/${leadelem.id}?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&append_to_response=images`

            let tvpeopleshows=`
            https://api.themoviedb.org/3/person/${leadelem.id}/tv_credits?api_key=7c0e9fb0f36aedea6e87df7efacb4f61&language=en-US`


            fetch(tvpeople).then(response=>{
                return response.json()
            }).then(actordata=>{
                console.log(actordata)


                // PRofile img



                let actorimg=castinfomodal.children[0].children[0].children[0].children[0].children[0].children[0].children[0]

                actorimg.setAttribute("src",`https://image.tmdb.org/t/p/w500${actordata.profile_path}`)


                // Actor name


                let actorname=castinfomodal.children[0].children[0].children[0].children[1].children[0].children[1]

                if(actordata.name!=null)
                {
                    actorname.innerText=`${actordata.name}`
                    console.log(actorname.innerHTML)
                    actorname.parentElement.classList.remove('d-none')

                }

                else{
                    actorname.parentElement.classList.add('d-none')
                }

                // Actorbday

               

                let actorbday=castinfomodal.children[0].children[0].children[0].children[1].children[1].children[1]

                if(actordata.birthday!=null)
                {
                    actorbday.innerText=`${actordata.birthday}`

                    console.log(actorname.innerHTML)
                    actorbday.parentElement.classList.remove('d-none')

                }

                else{
                    actorbday.parentElement.classList.add('d-none')
                }



                // Actor profession


                let actorprofess=castinfomodal.children[0].children[0].children[0].children[1].children[2].children[2]

                if(actordata.known_for_department!=null)
                {
                    actorprofess.innerText=`${actordata.known_for_department}`


                    console.log(actorname.innerHTML)
                    actorprofess.parentElement.classList.remove('d-none')

                }

                else{
                    actorprofess.parentElement.classList.add('d-none')
                }


                // Actor overview


                let actoroverview=castinfomodal.children[0].children[0].children[0].children[1].children[3].children[2]

                if(actordata.biography!="")
                {
                    actoroverview.innerText=`${actordata.biography}`



                    console.log(actorname.innerHTML)
                    actoroverview.parentElement.classList.remove('d-none')

                }

                else{
                    actoroverview.parentElement.classList.add('d-none')
                }
                

                // Actor images




                let actorimages=castinfomodal.children[0].children[0].children[0].children[1].children[5].children[1]

                Array.from(actordata.images.profiles).forEach(imageselem=>{

                    actorimages.innerHTML+=`
                    <div class="col-md-4 col-6 my-2">
                    <div class="ratio ratio-3x4">
                    <img src="https://image.tmdb.org/t/p/w500${imageselem.file_path}" alt="" class="img-fluid object-cover rounded-2 castinfo-images">      

                    </div>
                </div>  
                    `
                    console.log(imageselem)
                })

                castinfomodal.addEventListener("hidden.bs.modal",()=>{
                    actorimages.innerHTML=``
                    actoroverview.innerHTML=""
                    actorprofess.innerHTML=""
                    actorbday.innerHTML=""
                    actorname.innerHTML=""
                })




                



               
            fetch(tvpeopleshows).then(response=>{
                return response.json()
            }).then(popshowsdata=>{
                console.log(popshowsdata.cast)

                let popshowsarr= [] 

                popshowsdataarr=popshowsdata.cast
    

                    popshowsdataarr.sort((a, b) => b.vote_average - a.vote_average);

                Array.from(popshowsdataarr).forEach((shows,i)=>{
                    if(!(shows.character=="Self" || shows.character=="Himself" || shows.character.includes("Self") ||  shows.character.includes("self") || shows.character.includes("(voice)") || shows.character=="" || shows.popularity<5))
                    {
                        if(shows.vote_average>5)
                        {
                            popshowsarr.push(shows.name)

                        }
                        console.log(shows)


                

                    }

                   
                })
               console.log(popshowsarr.length==0,popshowsarr) 


                if(popshowsarr.length==0)
                {
                    let popshowsparent=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1].parentElement

                    console.log(popshowsparent)

                    popshowsparent.classList.add("d-none")

                }

                else{

                    let popshowsparent=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1].parentElement

                    popshowsparent.classList.remove("d-none")


                    popshowsarr=new Set(popshowsarr)

                   Array.from(popshowsarr).forEach((popshowsname,i)=>{


                        let popshows=castinfomodal.children[0].children[0].children[0].children[1].children[4].children[1]

                        console.log(i,(popshowsarr.size)-1)


                        popshows.previousElementSibling.innerHTML="Popular Shows :"


                       
                       
                            popshows.innerHTML+=` <div class="d-flex mb-1"> <span>${i+1}.</span>     <span class="px-md-2 px-1"> ${popshowsname}. </span> </div> `

                console.log(popshows)

                castinfomodal.addEventListener("hidden.bs.modal",()=>{
                    popshows.innerHTML=``
                })
                    })


                }

            castinfomodal.children[0].children[0].classList.remove("loading")





            

            })




            })


            // fetch tv show of actor
         
            
        })
        
    })
    



    })



})


// screenshot

fetch(movietvimagesurl).then(response=>{
    return response.json()
}).then(data=>{
    console.log(data);

    Array.from(ssrow).forEach(sselem=>{

        sselem.innerHTML=""

        Array.from(data.backdrops).forEach(ssimg=>{
            sselem.innerHTML+=`
            <div class="col-sm-6 hover-elem modalimg col-md-4 z-99 mb-20  col-xl-3 col-8 mx-2 position-relative  d-flex flex-column px-0" >
                                  
            <div class="ratio ratio-16x9 border border-theme box-shadow  rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${ssimg.file_path}" alt="" class="img-fluid object-cover " >
            </div>
                           
    
                            
    
                        </div>
            `
        })

        if(sselem.innerHTML==``)
        {
            sselem.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
        }

        let ssrowleftbtn=sselem.previousElementSibling;
        let ssrowrightbtn=ssrowleftbtn.previousElementSibling;

        rightbtnscroll(sselem,ssrowrightbtn)
        leftbtnscroll(sselem,ssrowleftbtn)
        
    })

    let imgelem=document.getElementsByClassName("modalimg");
    Array.from(imgelem).forEach(e=>{
        e.addEventListener("click",function(){
            Array.from(modaltvmovie).forEach(modalelem=>{
                let modalelemactive=new bootstrap.Modal(modalelem);
                modalelemactive.show();
                console.log(modalelem.children[0].children[0].children[0]);

                let imgkey=e.children[0].children[0].getAttribute("src")
                // console.log(imgkey)
               let modalelembody=modalelem.children[0].children[0].children[0];

               modalelembody.innerHTML=`
               <div class="img-videodiv ratio ratio-16x9 modal-border-radius">
               <img src="${imgkey}" alt="" class="img-fluid object-cover modal-border-radius" style="opacity:0.9;">
           </div>
                  
           `

           


            })
        })
    })
})




 


// recommendedmovies

fetch(movietvrecommendedurl).then(response=>{
    return response.json()
}).then(data=>{
    console.log(data.results,data)

    Array.from(recommendedmoviesrow).forEach(recommendrow=>{

        recommendrow.innerHTML=''

        Array.from(data.results).forEach(recommendmovie=>{
            recommendrow.innerHTML+=`
            <div class="col-sm-4 col-md-3 hover-scale col-xl-2 col-6 mx-2 position-relative  d-flex flex-column px-0" id
            =${recommendmovie.id} data-bs-type="tv">
                      
            <div class="ratio ratio-3x4 border border-theme box-shadow rounded-2">
            <img src="https://image.tmdb.org/t/p/w500${recommendmovie.poster_path}" alt="" class="img-fluid object-cover  " >
            </div>
                           
                            <h6 class="trending-title  fs-chng2 my-3 text-center">${recommendmovie.name}</h6>

                            

                        </div>`

                        let recommendedrowleftbtn=recommendrow.previousElementSibling;
                        let recommendedrowrightbtn=recommendedrowleftbtn.previousElementSibling;
                
                        rightbtnscroll(recommendrow,recommendedrowrightbtn)
                        leftbtnscroll(recommendrow,recommendedrowleftbtn)

        })


        if(recommendrow.innerHTML==``)
        {
            recommendrow.parentElement.parentElement.parentElement.parentElement.parentElement.classList.add("d-none")
        }
        

        recommendedparent=recommendrow.parentElement.parentElement.parentElement.previousElementSibling.children[0];
        recommendedparent.innerHTML=`Recommended Shows`
        console.log(recommendedparent)
    })

})


}




document.body.children[1].classList.add("d-none")
    
            document.body.children[0].classList.remove("d-none")

            


                
           


          
       




})






